# Runs once at install under KernelSU, APatch or Magisk; $MODPATH is the module.
# The app's root process (cli/, if any) ships in bin/.
if [ -d "$MODPATH/bin" ]; then
  set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
fi
# flutter_p0g: the programs it ships (generated at build).
set_perm_recursive "$MODPATH/flutter_webui" 0 0 0755 0755
set_perm_recursive "$MODPATH/webui_app_plane" 0 0 0755 0755
# flutter_p0g: the data folder /data/adb/extras_lab (generated at build).
[ -d /data/adb/modules/extras_lab ] || rm -rf /data/adb/extras_lab
KSU_MODULE=extras_lab /data/adb/ksud module config set webui.installed 1 || ui_print "! ksud module config failed: KernelSU 3.0+ or KernelSU Next 3.0+ is needed"
# flutter_p0g: install or update the app plane app (generated at build).
sh "$MODPATH/webui_app_plane/app-install.sh" 2>&1 | while IFS= read -r l; do ui_print "  $l"; done
