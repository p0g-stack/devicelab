# flutter-webui devicelab bring-up module.
set_perm_recursive "$MODPATH/flutter_webui" 0 0 0755 0755
