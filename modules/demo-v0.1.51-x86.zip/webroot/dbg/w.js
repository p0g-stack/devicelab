importScripts('../pkg/demo_native.js');
(async () => {
  try {
    const r = await fetch('../pkg/demo_native_bg.wasm');
    postMessage('fetch ' + r.status + ' ' + r.headers.get('content-type') + ' isResponse=' + (r instanceof Response));
    await wasm_bindgen('../pkg/demo_native_bg.wasm');
    postMessage('ok ' + wasm_bindgen.frb_get_rust_content_hash?.());
  } catch (e) { postMessage('err ' + e); }
})();
